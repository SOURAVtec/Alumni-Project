<html><head>
    <title>Alumni Feedback Form</title>


    <style>
        div{
            .animate-on-scroll {
        opacity: 2.3;
        transform: translateY(20px);
        transition: opacity 0.6s ease-out, transform 0.6s ease-out;
    }

    .animate-on-scroll.visible {
        opacity: 1;
        transform: translateY(0);
    }
        }
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #E8DFCA; 
}

header {
    background-color: #004d40; 
    color: #fff;
    padding: 1em 0;
    text-align: center;
}

main {
    padding: 1em;
}

section {
    margin: 2em auto;
    max-width: 600px;
    background-color: #ffffff; 
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    padding: 2em;
}

h2 {
    margin-top: 0;
    color: #004d40; 
}

form {
    display: flex;
    flex-direction: column;
}

label {
    margin-top: 0.5em;
    font-weight: bold;
    color: #004d40; 
}

input, textarea, select {
    margin-bottom: 1em;
    padding: 0.75em;
    border: 1px solid #004d40; 
    border-radius: 4px;
}

button {
    padding: 0.75em;
    background-color: #004d40; 
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 1em;
}

button:hover {
    background-color: #4F6F52; 
    text-decoration: underline;
}


    </style>
</head>
<div>
    <header>
        <div>
        <h1 style="font-family:times new roman; font-size: 280%; ">Alumni Feedback Form</h1>
    </header>
    
    <main>
        <div>
        <section id="feedback-form">
            
            <h2 style ="text-align:center;font-family:times new roman;font-size:230%">We Value Your Feedback</h2>
            <form id="form-feedback">
                <label for="name">Name:</label>
                <input type="text" id="name" required="">
                
                <label for="email">Email:</label>
                <input type="email" id="email" required="">
                
                <label for="graduation-year">Graduation Year:</label>
                <select id="year" required="" >
                    <option value="">Select The Year</option>
                    <option value="1">1<sup>st</sup></option>
                    <option value="2">2<sup>nd</sup></option>
                    <option value="3">3<sup>rd</sup></option>
                    <option value="4">4<sup>th</sup></option>
                    <option value="5">Others</option>
                </select>
                
                <label for="feedback">Feedback:</label>
                <textarea id="feedback" rows="5" required=""></textarea>
                
                <label for="rating">Overall Experience Rating:</label>
                <select id="rating" required="">
                    <option value="">Select a rating</option>
                    < id="r">
                    <option value="1"> Excellent </option>
                    <option value="2"> Very Good</option>
                    <option value="3"> Good</option>
                    <option value="4"> Fair</option>
                    <option value="5">Poor</option>
                </select>
                <button type="submit">Submit Feedback</button>
            </form>
        </section>
    </main>
    
</div></div>



</body></html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumni Association - Donate</title>
    
    <script src="https://www.paypal.com/sdk/js?client-id=AVgurk_SEt8x5djDQ3z6EQj84_gmy0EKMgPAKZefsqBPqT6s05fUmb6RHwxjljhugTntCVAM--30HL7c"></script>
    
    <style>
      * {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Roboto', sans-serif;
  background-color: #f9f9f9;
  color: #333;
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
}

.donation-container {
  background: #fff;
  padding: 2rem;
  border-radius: 10px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
  max-width: 500px;
  width: 100%;
  text-align: center;
}

.donation-form h2 {
  color: #004d40;
  margin-bottom: 1.5rem;
  font-size: 1.8rem;
  font-weight: 700;
}

.donation-form p {
  color: #666;
  margin-bottom: 1.5rem;
}

.donation-form label {
  display: block;
  text-align: left;
  margin-bottom: 0.5rem;
  font-weight: 600;
  color: #333;
}

.donation-form input[type="text"],
.donation-form input[type="email"],
.donation-form input[type="number"],
.donation-form select {
  width: 100%;
  padding: 0.8rem;
  margin-bottom: 1.5rem;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 1rem;
  transition: border-color 0.3s ease;
}

.donation-form input[type="text"]:focus,
.donation-form input[type="email"]:focus,
.donation-form input[type="number"]:focus,
.donation-form select:focus {
  border-color: #004d40;
  outline: none;
}

.donation-form button[type="submit"] {
  width: 100%;
  background: #004d40;
  color: #fff;
  padding: 0.8rem;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 1.1rem;
  font-weight: 600;
  text-transform: uppercase;
  transition: background 0.3s ease;
}

.donation-form button[type="submit"]:hover {
  background: #00332a;
}

.payment-details {
  display: none;
}

#credit-card-info {
  display: block;
}

    </style>


</head>

<body>
    <div class="donation-container">
        <div class="donation-form">
            <h2>Support Our Alumni Association</h2>
            <p>Your donation will help us continue our mission and support alumni activities.</p>

            <form id="donation-form">
                <label for="name">Full Name</label>
                <input type="text" id="name" name="name" required>

                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>

                <label for="amount">Donation Amount</label>
                <input type="number" id="amount" name="amount" min="1" placeholder="Enter the amount.." required>

                <div id="paypal-button-container"></div>
            </form>
        </div>
    </div>

    <script>
        paypal.Buttons({
            createOrder: function (data, actions) {
                const amount = document.getElementById('amount').value;
                return actions.order.create({
                    purchase_units: [{
                        amount: {
                            value: amount
                        }
                    }]
                });
            },
            onApprove: function (data, actions) {
                return actions.order.capture().then(function (details) {
                    alert('Donation successful! Thank you for your support, ' + details.payer.name.given_name);
                    document.getElementById('donation-form').submit();
                });
            }
        }).render('#paypal-button-container');
    </script>
</body>

</html>

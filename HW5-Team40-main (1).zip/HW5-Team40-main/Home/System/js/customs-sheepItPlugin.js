
jQuery(function($) {

	"use strict";


	

	
	
	/**
	* sheepItForm - Dynamic form
	*/
	var sheepItForm = $('#dynamicAddForm').sheepIt({
			separator: '<div style="width:100%; border-top:0 solid #ff0000; margin: 0;"></div>',
			allowRemoveLast: true,
			allowRemoveCurrent: true,
			allowRemoveAll: true,
			allowAdd: true,
			allowAddN: true,
			maxFormsCount: 10,
			minFormsCount: 0,
			iniFormsCount: 1,
			continuousIndex: true
	});
	
	var sheepItForm = $('#dynamicAddForm2').sheepIt({
			separator: '<div style="width:100%; border-top:0 solid #ff0000; margin: 0;"></div>',
			allowRemoveLast: true,
			allowRemoveCurrent: true,
			allowRemoveAll: true,
			allowAdd: true,
			allowAddN: true,
			maxFormsCount: 10,
			minFormsCount: 0,
			iniFormsCount: 1,
			continuousIndex: true
	});
	
	var sheepItForm = $('#dynamicAddForm3').sheepIt({
			separator: '<div style="width:100%; border-top:0 solid #ff0000; margin: 0;"></div>',
			allowRemoveLast: true,
			allowRemoveCurrent: true,
			allowRemoveAll: true,
			allowAdd: true,
			allowAddN: true,
			maxFormsCount: 10,
			minFormsCount: 0,
			iniFormsCount: 1,
			continuousIndex: true
	});
	
	
})(jQuery);





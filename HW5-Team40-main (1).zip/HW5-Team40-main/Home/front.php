<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumni Association - Home</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <header>
        <nav>
            <ul>
                <li><a href="#home">Home</a></li>
                <li><a href="\Alumni-Project\Contact\contact.php">About</a></li>
                <li><a href="https://app.powerbi.com/groups/me/reports/ea2e2662-533d-4875-ae0b-51b3bd4b4d61/842158bce20242a17390?experience=power-bi">Analytics</a></li>
                <li><a href="\Alumni-Project\Donation\Donations.php">Donation</a></li>
                <li><a href="\Alumni-Project\Registration\signup.php">Registration</a></li>
                <li><a href=.\System\index.php>Job Postings</a></li>
                <li><a href="\Alumni-Project\Feedback\Feedback.php">Feedback</a></li>
            </ul>
        </nav>
    </header>

    <main id="home">
        <section class="hero" >
            <div class="hero-content">
                <h1>Welcome to the Alumni Association</h1>
                <p>Celebrating the achievements and memories of our alumni.</p>
            </div>
        </section>

        <section class="showcase-grid">
            <div class="grid-item">
                <img src="Untitled design.png" alt="Event 1">
                <div class="overlay">
                    <h2>Networking Hub</h2>
                    <p>Sections to connect alumni based on shared interests and locations.</p>
                </div>
            </div>

            <div class="grid-item">
                <img src="award.jpg" alt="Alumni Achievement 1">
                <div class="overlay">
                    <h2>Alumni Directory</h2>
                    <p>Searchable database to find and connect with other alumni.</p>
                </div>
            </div>

            <a href="\Alumni-Project\Story\Story.php"><div class="grid-item">
                <img src="achievement2.jpg" alt="">
                <div class="overlay">
                    <h2>Success Story Tracking</h2>
                    <p>Showcase and track notable alumni achievements.</p>
                </div>
            </div></a>

            <a href="\Alumni-Project\Events\Events.php"><div class="grid-item">
                <img src="webinar.jpg" alt="Alumni Achievement 2">
                <div class="overlay">
                    <h2>Events and Reunions</h2>
                    <p>Exclusive webinar by industry leaders on October 22, 2024.</p>
                </div>
            </div></a>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Alumni Association. All rights reserved.</p>
    </footer>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const heading = document.querySelector('.hero-content h1');
            const text = heading.textContent;
            heading.textContent = '';
            let index = 0;
        
            function typeWriter() {
                if (index < text.length) {
                    heading.textContent += text.charAt(index);
                    index++;
                    setTimeout(typeWriter, 100); // Adjust speed by changing the timeout value
                }
            }
        
            typeWriter();
        });
        </script>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const navItems = document.querySelectorAll('nav ul li');
    
        navItems.forEach((item, index) => {
            item.style.opacity = 0;
            item.style.transform = 'translateX(-30px)';
    
            setTimeout(() => {
                item.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
                item.style.opacity = 1;
                item.style.transform = 'translateX(0)';
            }, 100 * index); // Delay each item by 100ms to create a staggered effect
        });
    });
    </script>
    
        



</body>

</html>

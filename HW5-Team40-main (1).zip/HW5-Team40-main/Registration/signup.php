<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up & Document Upload</title>
    <style>body {
    font-family: Arial, sans-serif;
    background-color: E8DFCA;
    color: #ffffff; 
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}

.signup-container {
    background: linear-gradient(135deg, #004d40, #00796b); 
    padding: 40px;
    border-radius: 8px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
    width: 350px;
    max-width: 100%;
}

.signup-form h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #ffffff;
}

.signup-form label {
    display: block;
    margin-bottom: 8px;
    color: #ffffff;
}

.signup-form input, 
.signup-form select {
    width: 100%;
    padding: 10px;
    margin-bottom: 20px;
    border: none;
    border-radius: 4px;
    box-sizing: border-box;
}

.signup-form input {
    background-color: #ffffff;
    color: #004d40;
}

.signup-form select {
    background-color: #004d40;
    color: #ffffff;
    border: 1px solid #00796b;
}

.signup-form button {
    width: 100%;
    padding: 10px;
    background-color: #00796b; 
    color: #ffffff;
    border: none;
    border-radius: 4px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
}

.signup-form button:hover {
    background-color: #004d40; 
}

#student-id-container, #alumni-id-container {
    display: none;
}

.signup-form button[type="submit"] {
    background-color: #00796b;
}

.signup-form button[type="submit"]:hover {
    background-color: #004d40;
}

@media (max-width: 480px) {
    .signup-container {
        padding: 20px;
    }

    .signup-form h2 {
        font-size: 24px;
    }
}</style>
</head>
<body>
    <div class="signup-container">
        <div class="signup-form">
            <h2>Create an Account</h2>
            <form id="signup-form" action="/document-upload" method="POST" enctype="multipart/form-data">
                <label for="user-type">I am a</label>
                <select id="user-type" name="user-type" required>
                    <option value="student">Student</option>
                    <option value="alumni">Alumni</option>
                </select>

                <label for="full-name">Full Name</label>
                <input type="text" id="full-name" name="full-name" required>

                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" placeholder="Use institutional email if student" required>

                <label for="grad-year">Graduation Year</label>
                <input type="number" id="grad-year" name="grad-year" required>

                <label for="degree">Degree/Program</label>
                <input type="text" id="degree" name="degree" required>

                <label for="id">Student ID/Alumni ID</label>
                <input type="text" id="id" name="id" required placeholder="Enter Student ID or Alumni ID">

                <label for="documents">Upload Documents</label>
                <input type="file" id="documents" name="documents[]" multiple required>

                <button type="submit">Sign Up & Upload</button>
            </form>
        </div>
    </div>

    <script>
        
        document.getElementById('user-type').addEventListener('change', function () {
            const placeholderText = this.value === 'student' ? 'Enter Student ID' : 'Enter Alumni ID';
            document.getElementById('id').placeholder = placeholderText;
            document.getElementById('id').value = ''; 
        });

        
        document.getElementById('signup-form').addEventListener('submit', function (e) {
            e.preventDefault(); 

            
            const button = this.querySelector('button');
            button.textContent = 'Submitting...';
            button.disabled = true;

            
            setTimeout(() => {
                
                alert('Form submitted successfully!');
                button.textContent = 'Sign Up & Upload';
                button.disabled = false;
            }, 2000);
        });

        
        window.addEventListener('load', function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    </script>
</body>
</html>
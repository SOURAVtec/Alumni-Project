<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Registration</title>
    <link rel="stylesheet" href="Registrationstyles.css">
</head>

<body>
    <header>
        <h1>Register for an Event</h1>
    </header>

    <main>
        <section id="registration-form">
            <h2>Join Us for an Exciting Event!</h2>
            <form id="eventForm">
                <label for="event">Select Event:</label>
                <select id="event" name="event" required>
                    <option value="">Choose an event</option>
                    <option value="annual_reunion_2024">Annual Alumni Reunion 2024</option>
                    <option value="networking_night_2024">Career Networking Night</option>
                </select>

                <label for="name">Full Name:</label>
                <input type="text" id="name" name="name" required>

                <label for="email">Email Address:</label>
                <input type="email" id="email" name="email" required>

                <label for="phone">Phone Number:</label>
                <input type="tel" id="phone" name="phone" required>

                <label for="graduation-year">Graduation Year:</label>
                <input type="number" id="graduation-year" name="graduation_year" required>
                <li><a href="member.html">Members</a></li>

                <button type="submit">Register Now</button>
            </form>
        </section>
    </main>

    <script src="script.js">
        document.getElementById('eventForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const name = document.getElementById('name').value;
    const eventSelected = document.getElementById('event').value;

    if (name && eventSelected) {
        alert(`Thank you, ${name}! You have successfully registered for the ${eventSelected}.`);
        
        this.reset();
    } else {
        alert('Please fill in all the fields.');
    }
});

    </script>
</body>

</html>
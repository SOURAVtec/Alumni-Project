<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumni Events & Reunions</title>
    <link rel="stylesheet" href="Eventstyle.css">
</head>

<body>
    <header>
        <h1>Upcoming Events & Reunions</h1>
    </header>

    <main>
        <section id="events">
            <h2>Join Us at Our Upcoming Events</h2>
            <div class="event-card">
                <img src="event1.png" alt="Event 1">
                <div class="event-info">
                    <h3>Annual Alumni Reunion 2024</h3>
                    <p>Date: April 18-20, 2024</p>
                    <p>Location: Lindenwood College Campus</p>
                    <p>Join us for a day of reconnecting with fellow alumni, faculty, and current students. Enjoy a
                        series of talks, workshops, and networking sessions.</p>
                    <button>Register Now</button>
                </div>
            </div>

            <div class="event-card">
                <img src="event2.png" alt="Event 2">
                <div class="event-info">
                    <h3>Career Networking Night</h3>
                    <p>Date: October 02, 2024</p>
                    <p>Location: Ensminger Pavillion</p>
                    <p>An evening of networking with industry leaders, alumni, and potential employers. Enhance your
                        professional connections and explore new opportunities.</p>
                    <button><a href="eve" class="btn btn-success">Register Now</a></button>
                </div>
            </div>

         
        </section>
    </main>


    <script src="script.js">document.querySelectorAll('button').forEach(button => {
            button.addEventListener('click', () => {
                alert('Registration functionality coming soon!');
            });
        });
    </script>


</body>

</html>
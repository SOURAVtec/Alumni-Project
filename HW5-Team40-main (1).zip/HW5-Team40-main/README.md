# Welcome to Hackerwar 5.0 | CODEX

## 📢 Hackathon Guidelines for All Teams

Hey everyone! As we dive into the hackathon, please keep the following guidelines in mind:

<b>Team Leaders:</b> Please ensure you mention the following in your team's text channel:
```
Problem Statement (PS) Number
PS Link
Brief Description of your project
Upload your PPT
```
<ul>
<li>
  Teams should push their code into their respective repositories (GitHub) every <b>2 hours</b> during the event.
</li>
<li>
   Teams are not allowed to work on a project before the event and open-source it solely for the purpose of using the code during the event.
</li>
</ul>

Let's keep things smooth and have an amazing hackathon! Good luck! 🚀

Generated Using GitBulk-Hackerwar by 
<a href="https://www.github.com/whysosaket">
whysosaket
</a>
 ❤💫 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumni Success Stories</title>
    

    <style>
        body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
}

header {
    background-color: #004d40;
    color: white;
    padding: 10px 0;
    text-align: center;
}

main {
    padding: 20px;
}

h1{
    color: white;
}
h2 {
    color: white;
}

#intro, #success-stories, #submit-story {
    margin-bottom: 20px;
    padding: 20px;
    background-color: white;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

form {
    display: flex;
    flex-direction: column;
}

label {
    margin-top: 10px;
}

input, textarea {
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

button {
    margin-top: 10px;
    padding: 10px;
    border: none;
    background-color: #004d40;
    color: white;
    border-radius: 4px;
    cursor: pointer;
}

button:hover {
    background-color: #45a049;
}

#stories-list {
    margin-top: 20px;
}

.story-item {
    margin-bottom: 15px;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 4px;
    background-color: #fff;
}

#success-stories {
    height: 550px;
    background-image: url('success.jpg'); 
    background-size: cover; 
    background-position: center; 
    background-repeat: no-repeat; 
    padding: 20px; 
    color: white; 
    border-radius: 8px; 
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); 
}
#intro{
    height: 550px;
    background-image: url('success1.png'); 
    background-size: cover; 
    background-position: center; 
    background-repeat: no-repeat; 
    padding: 20px; 
    color: white; 
    border-radius: 8px; 
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); 

}


    </style>


</head>
<body>
    <header>
        <h1>Alumni Success Stories</h1>
    </header>
    
    <main>
        <section id="intro">
            <h2>Celebrating Our Alumni</h2>
            <p>Discover the remarkable achievements of our alumni and how they are making an impact in their fields.</p>
        </section>
        
        <section id="success-stories">
            <h2>Success Stories</h2>
            <div id="stories-list">
               
            </div>
        </section>
        
        <section id="submit-story">
            <h2>Submit Your Success Story</h2>
            <form id="story-form">
                <label for="name">Name:</label>
                <input type="text" id="name" required>
                
                <label for="graduation-year">Graduation Year:</label>
                <input type="text" id="graduation-year" required>
                
                <label for="story">Success Story:</label>
                <textarea id="story" rows="5" required></textarea>
                
                <button type="submit">Submit</button>
            </form>
        </section>
    </main>
    
    <footer>
        <p>&copy; 2024 Government Engineering College</p>
    </footer>

    <script>

document.addEventListener('DOMContentLoaded', () => {
    const storyForm = document.getElementById('story-form');
    const storiesList = document.getElementById('stories-list');

   
    function addStory(name, year, storyText) {
        const storyItem = document.createElement('div');
        storyItem.className = 'story-item';
        storyItem.innerHTML = `
            <h3>${name} (${year})</h3>
            <p>${storyText}</p>
        `;
        storiesList.appendChild(storyItem);
    }

    
    storyForm.addEventListener('submit', (event) => {
        event.preventDefault();

        const name = document.getElementById('name').value;
        const graduationYear = document.getElementById('graduation-year').value;
        const story = document.getElementById('story').value;

        if (name && graduationYear && story) {
            addStory(name, graduationYear, story);

            
            storyForm.reset();
        }
    });
});

    </script>


</body>
</html>
